(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1mojsay._.js","static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1os8b5a._.js","static/chunks/175g_next_dist_compiled_next-devtools_index_0dr9k8_.js","static/chunks/175g_next_dist_compiled_react-dom_0j__vwd._.js","static/chunks/175g_next_dist_compiled_react-server-dom-turbopack_1w3a98r._.js","static/chunks/175g_next_dist_compiled_1fnnn98._.js","static/chunks/175g_next_dist_client_05tgtbc._.js","static/chunks/175g_next_dist_21bcunw._.js","static/chunks/0zix_@swc_helpers_cjs_0hi-e47._.js"],
    source: "entry"
});
