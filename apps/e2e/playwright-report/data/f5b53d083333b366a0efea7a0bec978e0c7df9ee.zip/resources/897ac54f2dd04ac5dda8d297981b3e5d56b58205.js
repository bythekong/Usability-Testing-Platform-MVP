(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0pffpql._.css","static/chunks/node_modules__pnpm_0ehqhi5._.js","static/chunks/_1xvvrky._.js","static/chunks/_0eryn--._.js","static/chunks/node_modules__pnpm_20pkl6o._.js"],
    source: "entry"
});
